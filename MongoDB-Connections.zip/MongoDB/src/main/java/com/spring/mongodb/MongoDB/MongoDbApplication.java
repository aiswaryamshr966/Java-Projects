package com.spring.mongodb.MongoDB;

import java.net.UnknownHostException;
import java.util.ArrayList;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.data.mongo.MongoClientDependsOnBeanFactoryPostProcessor;

import com.mongodb.DB;
import com.mongodb.MongoClient;


@SpringBootApplication
public class MongoDbApplication {

	public static void main(String[] args) throws UnknownHostException {
		MongoClient mongo = new MongoClient();
		DB db = mongo.getDB("HyperCars");
		ArrayList<String> al = new ArrayList<String>();
		al = (ArrayList<String>) mongo.getDatabaseNames();
		System.out.println("List Of Databases : "+al);
		//SpringApplication.run(MongoDbApplication.class, args);
	}

}
