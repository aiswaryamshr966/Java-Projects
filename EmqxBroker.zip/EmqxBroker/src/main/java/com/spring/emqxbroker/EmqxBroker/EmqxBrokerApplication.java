package com.spring.emqxbroker.EmqxBroker;

import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

public class EmqxBrokerApplication {

	public static void main(String[] args) {
		String broker = "tcp://localhost:1883";
		String clientId = "AiswaryaMishra";
		
		//Using Memory persistence
		MemoryPersistence memory = new MemoryPersistence();
		try {
			MqttClient sampleClient = new MqttClient(broker, clientId, memory); //Setting up Links
			MqttConnectOptions con = new MqttConnectOptions(); //Creating Connection Options
			con.setCleanSession(true);
			System.out.println("Connecting to Broker : "+broker); //Setting a Message for the connection
			sampleClient.connect(con);
			System.out.println("Connection Established");
		} catch (MqttException me) {
			System.out.println("Reason "+me.getReasonCode());
			System.out.println("Message "+me.getMessage());
			System.out.println("Localized Message "+me.getLocalizedMessage());
			System.out.println("Cause "+me.getCause());
			System.out.println("Exception "+me);
			me.printStackTrace();
		}
	}

}
