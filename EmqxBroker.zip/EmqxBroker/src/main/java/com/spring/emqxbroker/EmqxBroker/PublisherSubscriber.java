package com.spring.emqxbroker.EmqxBroker;

import java.text.MessageFormat;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

public class PublisherSubscriber {
	public static void main(String[] args) {
		String broker = "tcp://localhost:1883";
		String clientId = "Super Cars";
		
		//Using Memory Persistence
		MemoryPersistence memory = new MemoryPersistence();
		try {
			MqttClient sampleClient = new MqttClient(broker, clientId, memory);
			MqttConnectOptions con = new MqttConnectOptions();
			con.setCleanSession(true);
			System.out.println("Connecting To The Broker : "+broker);
			sampleClient.connect();
			System.out.println("Connection Established");
			
			//Defining The Topics
			String topics = "Cars";
			System.out.println("Subscribe To The Topic : "+topics);
			sampleClient.subscribe(topics);
			sampleClient.setCallback(new MqttCallback() {
				
				@Override
				public void messageArrived(String topic, MqttMessage message) throws Exception {
					String message1 = MessageFormat.format("{0} Has Arrived For Topic {1}.", new String(message.getPayload()),topics);
					System.out.println("The Message : "+message);
				}
				
				@Override
				public void deliveryComplete(IMqttDeliveryToken token) {
					// TODO Auto-generated method stub
					
				}
				
				@Override
				public void connectionLost(Throwable cause) {
					// TODO Auto-generated method stub
					
				}
			});
			
			//Publication of the content with the message
			String content = "Message From Publisher";
			int qos = 2;
			System.out.println("Publishing Message : "+content);
			MqttMessage message = new MqttMessage(content.getBytes());
			message.setQos(qos);
			sampleClient.publish(topics, message);
			System.out.println("Message Published");
			
		} catch (MqttException me) {
			System.out.println("Reason "+me.getReasonCode());
			System.out.println("Cause "+me.getCause());
			System.out.println("Exception "+me);
			System.out.println("Localized Message "+me.getLocalizedMessage());
			System.out.println("Message "+me.getMessage());
			me.printStackTrace();
		}
	}
}
