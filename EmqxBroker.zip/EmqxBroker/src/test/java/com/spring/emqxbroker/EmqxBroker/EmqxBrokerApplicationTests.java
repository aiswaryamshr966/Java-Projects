package com.spring.emqxbroker.EmqxBroker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmqxBrokerApplicationTests {

	@Test
	void contextLoads() {
	}

}
