package com.spring.iterators.References;

import java.util.Enumeration;
import java.util.Vector;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
public class IterEnumeration implements Iterations {
	public void iteration(Vector vector) {
		System.out.println("......................Enumeration....................");
		for (int i = 0; i <= 10; i++) {
			vector.addElement(i);
		}
		System.out.println("The Vector : "+ vector);
		Enumeration e = vector.elements();
		while (e.hasMoreElements()) {
			int i = (Integer) e.nextElement();
			System.out.println("The value of i : "+i );
		}
	}
}
