package com.spring.iterators.SpringIteratorsReferences;

import java.util.Vector;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Description;
import com.spring.iterators.References.IterEnumeration;
import com.spring.iterators.References.IterIteration;
import com.spring.iterators.References.IterListIteration;
import com.spring.iterators.References.Iterations;

@Configuration
public class SpringIteratorsReferencesApplication {
		@Bean(name = "iterationsBean")
		@Description("This Sample Executes Different iterations")
		public Iterations iterations() {
			return new IterIteration();
	}
}
