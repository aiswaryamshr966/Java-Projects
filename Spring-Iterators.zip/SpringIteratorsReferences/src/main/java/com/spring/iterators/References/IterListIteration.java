package com.spring.iterators.References;

import java.util.ArrayList;
import java.util.ListIterator;
import java.util.Vector;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Primary
public class IterListIteration implements Iterations {
	public void iteration(Vector vector) {
		System.out.println(".....................List Iteration........................");
		for (int i = 0; i <= 20; i++) {
			vector.add(i);
		}
		System.out.println("Vector : "+vector);
		//Implementing ListIterator
		ListIterator lister = vector.listIterator();
		while (lister.hasNext()) {
			int i = (int) lister.next();
			System.out.println("i : "+i);
			if (i%2==0) {
				i++;
				lister.set(i); //to set method to change the value
				lister.add(i); //to add the change to the arraylist
			}
		}
		System.out.println();
		System.out.println("Vector : "+vector);
	}
}
