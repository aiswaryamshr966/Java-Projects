package com.spring.iterators.References;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Vector;

public class IterIteration implements Iterations {
	public void iteration(Vector vector) {
		System.out.println("..................Iteration...............");
				for (int i = 0; i <= 20; i++) {
					vector.add(i);
				}
				System.out.println("Vector : "+vector);
				
				//Implementing Iterator
				//Note: The iterator will always point to the index just before the first element of the Vector
				Iterator iterator = vector.iterator();
				while (iterator.hasNext()) {
					int i = (Integer) iterator.next();
					System.out.println("i : "+i);
					if (i%2==0) {
						iterator.remove();
					}
				}
				System.out.println();
				System.out.println("Vector : "+vector);
	}
}
