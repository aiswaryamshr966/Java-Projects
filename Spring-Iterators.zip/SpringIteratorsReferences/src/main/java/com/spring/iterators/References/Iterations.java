package com.spring.iterators.References;

import java.util.Vector;

public interface Iterations {
	public void iteration(Vector vector);
}
