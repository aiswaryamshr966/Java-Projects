import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Vector;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.spring.iterators.References.Iterations;
import com.spring.iterators.SpringIteratorsReferences.SpringIteratorsReferencesApplication;

public class AppMain {
	public static void main(String[] args) throws IOException {
		AbstractApplicationContext context = new AnnotationConfigApplicationContext(SpringIteratorsReferencesApplication.class);
		Iterations bean = (Iterations) context.getBean("iterationsBean");
		Vector vector = new Vector();
		bean.iteration(vector);
		context.close();
	}
}
