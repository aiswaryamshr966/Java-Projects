import java.util.Vector;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.spring.iterators.References.Iterations;

@Component
public class Algorithm {
	@Autowired
	private Iterations iterations;

	public Algorithm(Iterations iterations) {
		super();
		this.iterations = iterations;
	}

	public void algorithm(Vector vector) {
	}
}
