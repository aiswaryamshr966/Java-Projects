package com.spring.iterators.SpringIteratorsReferences;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringIteratorsReferencesApplicationTests {

	@Test
	void contextLoads() {
	}

}
