import java.util.concurrent.TimeUnit;

import org.eclipse.paho.client.mqttv3.MqttException;

public class Main {
	private static ChatClient chatClient;
	private static boolean running = true;
	
	public static void main(String[] args) throws MqttException, InterruptedException {
		String alias = ChatWindow.getInput("Please enter your chat alias : ");
        chatClient = new ChatClient(alias);
        ChatWindow.printHelper();
        while (running) {
            String input = ChatWindow.getInput();
            running = ChatWindow.processInput(input, chatClient);
            TimeUnit.SECONDS.sleep(1L);
        }
        disconnect();
	}

	private static void disconnect() throws MqttException {
		chatClient.closeClient();
	}
}
