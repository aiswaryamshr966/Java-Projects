

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.Scanner;

import org.eclipse.paho.client.mqttv3.MqttException;

public class ChatWindow {
	private static final String NEW_LINE = "\n";
	private static final String SEPARATOR = "::";
	private static final Scanner scanner = new Scanner(System.in);
	private static final BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(System.out));
	private static final String COMMAND_DELIMETER = " ";
	private static final String EXIT_COMMAND = "exit";
	private static final String JOIN_GROUP_COMMAND = "join";
	private static final String LEAVE_GROUP_COMMAND = "leave";
	private static final String HELP_COMMAND = "help";
	private static final String HELP_STRING = "Use <Alias/Group Message> to Chat to a Desired Group/Person" +
            NEW_LINE + "<join group_name> to Join a Group Chat" + 
			NEW_LINE + "<leave group_name> to Leave a Group Chat"+
            NEW_LINE + "<exit> to Exit" + 
			NEW_LINE;
	
	//Encode a given message with the sender :: message
	public static String encodeMessage(String sender, String message) {
        return sender + SEPARATOR + message;
    }

	public static void outputToChatWindow(String string) {
		try {
			writer.write(" >> "+ string + NEW_LINE);
			writer.flush();
		} catch (IOException ioe) {
			//Null
		}
	}
	
	//Get input from the chat window
	public static String getInputFromChatWindow() {
		return scanner.nextLine();
	}
	
	//Output the given message to the console
	public static void decodeAndOutputMessage(String chatFrom, String string) {
		StringBuilder output = new StringBuilder();
		if (null==chatFrom) {
			output.append("Personal Message");
		} else {
			output.append("Chat With").append(chatFrom).append(NEW_LINE);
		}
		String decoder[] = string.split(SEPARATOR);
        if (decoder.length == 1) { // Info message
            output.append("Info : ").append(decoder[0]);
        } else if (decoder.length == 2) { // chat message
            output.append("from ").append(decoder[0]).append(NEW_LINE).append(decoder[1]);
        } else {
            output.append("Invalid message received from the server.");
        }
        output.append(NEW_LINE).append("Waiting for your input. Use <help> for more info").append(NEW_LINE);
        outputToChatWindow(output.toString());
    }
	
	//Request and read user from the console giving a message to specify the request
	public static String getInput(String message) {
        ChatWindow.outputToChatWindow(message);
        return getInputFromChatWindow();
    }
	
	//Directly read the input from the console, use when user is already notified about the input
	public static String getInput() {
		return getInputFromChatWindow();
	}
	
	/**
	 *  Process a given user input and take actions accordingly.
     * - Set exit flag
     * - Send messages
     * - Join a group conversation
     * - Leave a group conversation
	 */
	public static boolean processInput(String input, ChatClient chatClient) throws MqttException {
        boolean running = true;
        if (EXIT_COMMAND.equalsIgnoreCase(input)) {
            running = false;
        } else if (HELP_COMMAND.equalsIgnoreCase(input)) {
            printHelper();
        } else {
            String[] inputArgs = input.split(COMMAND_DELIMETER, 2);
            int argsLength = inputArgs.length;
            if (2 == argsLength) {
                String arg1 = inputArgs[0];
                String arg2 = inputArgs[1];
                if (JOIN_GROUP_COMMAND.equalsIgnoreCase(arg1)) {
                    chatClient.startGroupConversation(arg2);
                } else if (LEAVE_GROUP_COMMAND.equalsIgnoreCase(arg1)) {
                    chatClient.endGroupConversation(arg2);
                } else {
                    chatClient.sendMessage(arg1, arg2);
                }
            } else {
                outputToChatWindow("Incorrect command.");
                printHelper();
            }
        }
        return running;
    }

	public static void printHelper() {
		outputToChatWindow(HELP_STRING);
	}
}
