

import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttPersistenceException;

//For a chat client messages should be recieved atleast once, which is qos = 2 in MQTT
public class ChatClient {
	private static final int qos = 2;
	private MQTTClient mqttClient;
	
	public ChatClient(String name) throws MqttException {
        mqttClient = new MQTTClient(name);
        mqttClient.subscribe(name, qos);
    }
	
	//Start of join the group chat
	public void startGroupConversation(String groupName) throws MqttException {
		mqttClient.subscribe(groupName, qos);
		ChatWindow.outputToChatWindow("Joined The Group Chat : "+groupName);
	}
	
	//Leave the group chat
	public void endGroupConversation(String groupName) throws MqttException {
		mqttClient.unsubscribe(groupName);
		ChatWindow.outputToChatWindow("Left The Group Chat : "+groupName);
	}
	
	//Send a chat message
	public void sendMessage(String chatName, String message) throws MqttPersistenceException, MqttException {
		mqttClient.sendMessage(chatName, message, qos);
	}
	
	//Close the chat client
	public void closeClient() throws MqttException {
		mqttClient.disconnect();
	}
}
