

import java.io.File;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.MqttPersistenceException;
import org.eclipse.paho.client.mqttv3.persist.MqttDefaultFilePersistence;

//MQTT Client which is used by the chat client to send and recieve messages
public class MQTTClient implements MqttCallback{
	private static final String broker = "tcp://localhost:1883";
	private static final String tmpdir = System.getProperty("java.io.tmpdir");
	private MqttClient mqttClient;
	private final String clientId;
	private static final String DEFAULT_USERNAME = "ADMIN";
	private static final String DEFAULT_PASSWORD = "ADMIN";
	
	//Connection Establishment using Constructor
	public MQTTClient(String clientId) throws MqttException {
		super();
		this.clientId = clientId;
		MqttConnectOptions con = new MqttConnectOptions();
		con.setCleanSession(true);
		con.setUserName(DEFAULT_USERNAME);
		con.setPassword(DEFAULT_PASSWORD.toCharArray());
		mqttClient = new MqttClient(broker, clientId, new MqttDefaultFilePersistence(tmpdir + File.separator + clientId));
		mqttClient.setCallback(this);
		mqttClient.connect(con);
	}
	
	//Subscribing to a given topic over a given qos
	public void subscribe(String topic, int qos) throws MqttException {
        mqttClient.subscribe(topic, qos);
    }
	
	//Unsubscribe from a given topic after publishing to the chat server.
	public void unsubscribe(String topic) throws MqttPersistenceException, MqttException {
		mqttClient.publish(topic, (clientId + "Has Left The Conversation").getBytes(),2,false);
		mqttClient.unsubscribe(topic);
	}
	
	//Send message to a given topic
	public void sendMessage(String topic, String message, int qos) throws MqttPersistenceException, MqttException {
		String encodedMessage = ChatWindow.encodeMessage(clientId, message);
		mqttClient.publish(topic, encodedMessage.getBytes(),qos,false);
	}
	
	//Disconnet the mqtt client from the server
	public void disconnect() throws MqttException {
		mqttClient.disconnect();
	}
	
	//Handling the losing of the connecton from the server
	public void connectionLost(Throwable cause) {
		ChatWindow.outputToChatWindow("Connection Lost");
	}
	
	//Handle recieving message from the server
	public void messageArrived(String topic, MqttMessage message) throws Exception {
		synchronized (this.getClass()) {
            String chatFrom = null;
            // If message is received through the personal channel it is a personal message. Otherwise it is a group chat
            if (!clientId.equals(topic)) {
                chatFrom = topic;
            }
            ChatWindow.decodeAndOutputMessage(chatFrom, message.toString());
        }
	}

	//Notification to the chat console on the successfull delivery
	public void deliveryComplete(IMqttDeliveryToken token) {
		synchronized (this.getClass()) {
            for (String topic : token.getTopics()) {
                String chatName = null;
                if (!topic.equals(clientId)) {
                    chatName = topic;
                }
                ChatWindow.decodeAndOutputMessage(chatName, "Message Sent");
            }
        }
	}
}
