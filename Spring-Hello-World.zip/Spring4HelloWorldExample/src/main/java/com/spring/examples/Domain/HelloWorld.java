package com.spring.examples.Domain;

public interface HelloWorld {
	public void sayHello(String name);
}
