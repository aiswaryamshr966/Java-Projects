import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.spring.examples.Domain.HelloWorld;
import com.spring.examples.Spring4HelloWorldExample.Spring4HelloWorldExampleApplication;

public class AppMain {
	public static void main(String[] args) {
		AbstractApplicationContext context = new AnnotationConfigApplicationContext(Spring4HelloWorldExampleApplication.class);
		HelloWorld bean = (HelloWorld) context.getBean("helloWorldBean");
		bean.sayHello("Spring 4");
		context.close();
	}
}
