package com.spring.examples.Spring4HelloWorldExample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Spring4HelloWorldExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
