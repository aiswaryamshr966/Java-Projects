import java.util.ArrayList;
import java.util.ListIterator;

public class ListIteration {
	public static void main(String[] args) {
		ArrayList al = new ArrayList();
		for (int i = 0; i <= 20; i++) {
			al.add(i);
		}
		System.out.println("Array List : "+al);
		//Implementing ListIterator
		ListIterator lister = al.listIterator();
		while (lister.hasNext()) {
			int i = (int) lister.next();
			System.out.println("i : "+i);
			if (i%2==0) {
				i++;
				lister.set(i); //to set method to change the value
				lister.add(i); //to add the change to the arraylist
			}
		}
		System.out.println();
		System.out.println("Array List : "+al);
	}
}
