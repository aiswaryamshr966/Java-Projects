import java.util.AbstractCollection;
import java.util.ArrayList;
import java.util.TreeSet;

public class Abstraction {
	public static void main(String[] args) {
		//Creating an empty AbstarctColection class
		AbstractCollection<Object> abs = new ArrayList<Object>();
		
		//add() method is used to add elements into an arraylist
		abs.add("Aiswarya Mishra");
		abs.add("Soumya Ranjan Satpathy");
		abs.add("Amarnath Sahoo");
		abs.add("Subham Mohapatra");
		
		System.out.println("Abstract Collection : "+ abs);
		AbstractCollection<Object> tree = new TreeSet<Object>(); //Creating a new tree set for adding the elements in the array list
		tree.addAll(abs); //addAll() method adds all the objects in the array list to the tree set
		System.out.println("Abstract Collection Tree Set : "+tree);
		abs.clear(); //clearing all the elements in the Array List
		if (abs.isEmpty()) {
			System.out.println("Array List Is Empty");
		} else {
			System.out.println("Array List Contains : "+abs);
		}
		System.out.println("The size of the tree set is : "+tree.size());
	}
}
