import java.util.ArrayList;
import java.util.Iterator;

public class Iteration {
	public static void main(String[] args) {
		//Creating an Array List
		ArrayList<Integer> al = new ArrayList<Integer>();
		for (int i = 0; i <= 20; i++) {
			al.add(i);
		}
		System.out.println("ArrayList : "+al);
		
		//Implementing Iterator
		//Note: The iterator will always point to the index just before the first element of the Array List
		Iterator iterator = al.iterator();
		while (iterator.hasNext()) {
			int i = (Integer) iterator.next();
			System.out.println("i : "+i);
			if (i%2==0) {
				iterator.remove();
			}
		}
		System.out.println();
		System.out.println("Array List : "+al);
		
	}
}
