import java.util.AbstractCollection;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.Vector;

public class References {
	public static void main(String[] args) {
		Vector<Integer> vector = new Vector<Integer>();
		for (int i = 0; i <= 20; i++) {
			vector.add(i);
		}
		
		Enumeration<Integer> enumerator = vector.elements();
		Iterator<Integer> iterator = vector.iterator();
		ListIterator<Integer> lister = vector.listIterator();
		
		//Printing the elements using iterator references
		System.out.println("vector using enumerator : "+enumerator.nextElement());
		System.out.println("vector using iterator : "+iterator.next());
		System.out.println("vector using list iterator : "+lister.next());
		
		//getting the classes of the iterator references
		System.out.println(enumerator.getClass().getName());
		System.out.println(iterator.getClass().getName());
		System.out.println(lister.getClass().getName());
	}
}
