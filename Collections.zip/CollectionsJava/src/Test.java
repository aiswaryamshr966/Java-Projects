import java.util.*;
import java.io.*;

public class Test {
	public static void main(String[] args) {
		//Creating instances of Arrays, Vectors and Hashtables
		int[] arr = new int[] {23,67,78,45,89};
		Vector<Integer> vector = new Vector();
		Hashtable<Integer, String> hash = new Hashtable();
		vector.addElement(1020428);
		vector.addElement(1020447);
		hash.put(1,"Aiswarya");
		hash.put(2,"Himanshu");
		
		//Array instance creation requires []
		//Vector and Hastable instance creation requires ()
		//Vector element insertion requires addElement()
		//Hashtable insertion requires put()
		
		//Accessing the first element of the array, vector and hashtable
		System.out.println(arr[0]);
		System.out.println(vector.elementAt(0)); //vector elements are accessed using elementAt()
		System.out.println(hash.get(1)); //hashtable elements are accessed using get()
	}
}
