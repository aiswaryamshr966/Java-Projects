import java.util.Enumeration;
import java.util.Vector;

public class Enumerator {
	public static void main(String[] args) {
		Vector vector = new Vector();
		for (int i = 0; i <= 10; i++) {
			vector.addElement(i);
		}
		System.out.println("The Vector : "+ vector);
		Enumeration e = vector.elements();
		while (e.hasMoreElements()) {
			int i = (Integer) e.nextElement();
			System.out.println("The value of i : "+i );
		}
	}
}
